function yesClick() {
  document.getElementById("text").innerHTML =
    "Goood Daddy 💋";
  startHearts();
}

function moveNo() {
  let btn = document.getElementById("noBtn");
  let x = Math.random() * 200 - 100;
  let y = Math.random() * 200 - 100;
  btn.style.transform = `translate(${x}px, ${y}px)`;
}

// NO click panna message
document.getElementById("noBtn").addEventListener("click", function(){
  document.getElementById("text").innerHTML = "(athula nee solla koodathu)";
});

// Floating hearts for YES
function startHearts() {
  for(let i=0; i<20; i++) {
    let heart = document.createElement("div");
    heart.classList.add("heart");
    heart.innerHTML = "💖";
    heart.style.left = Math.random() * window.innerWidth + "px";
    heart.style.animationDuration = 2 + Math.random() * 3 + "s";
    document.body.appendChild(heart);

    setTimeout(() => heart.remove(), 5000);
  }
}